def validate_side(side):
    return side in ["BUY", "SELL"]

def validate_qty(qty):
    return qty > 0

def validate_price(price):
    return price > 0

def calc_pnl(entry, exit, qty, side):
    if side == "BUY":
        return (exit - entry) * qty
    else:
        return (entry - exit) * qty

def slippage_ok(mark_price, intended_price, max_slippage_percent):
    slip = abs(mark_price - intended_price) / intended_price * 100
    return slip <= max_slippage_percent

mark = float(bot.client.futures_mark_price(symbol=s)["markPrice"])
if not slippage_ok(mark, price, 0.3):
    print("Slippage too high. Order blocked.")
    continue

