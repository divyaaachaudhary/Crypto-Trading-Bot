import json
import os
from datetime import datetime

FILE = "logs/trade_history.json"

if not os.path.exists("logs"):
    os.makedirs("logs")

if not os.path.exists(FILE):
    with open(FILE, "w") as f:
        json.dump([], f)

def save_trade(trade):
    if "timestamp" not in trade:
        trade["timestamp"] = datetime.now().isoformat()
    with open(FILE, "r") as f:
        data = json.load(f)
    data.append(trade)
    with open(FILE, "w") as f:
        json.dump(data, f, indent=4)

def get_trades():
    with open(FILE) as f:
        return json.load(f)
