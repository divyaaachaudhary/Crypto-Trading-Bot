from binance import Client
from config import API_KEY, API_SECRET
from logger import logger
import time

class BasicBot:
    def __init__(self):
        self.client = Client(API_KEY, API_SECRET)
        self.client.FUTURES_URL = "https://testnet.binancefuture.com"
        self.client.API_URL = "https://testnet.binancefuture.com"
        logger.info("Connected to Binance FUTURES TESTNET")

    def get_balance(self):
        return self.client.futures_account_balance()

    def set_leverage(self, symbol, leverage):
        return self.client.futures_change_leverage(symbol=symbol, leverage=leverage)

    def market_order(self, symbol, side, quantity):
        logger.info(f"Placing MARKET {side} {symbol} {quantity}")
        return self.client.futures_create_order(
            symbol=symbol, side=side, type="MARKET", quantity=quantity
        )

    def limit_order(self, symbol, side, quantity, price):
        logger.info(f"Placing LIMIT {side} {symbol} {quantity} @ {price}")
        return self.client.futures_create_order(
            symbol=symbol, side=side, type="LIMIT",
            timeInForce="GTC", quantity=quantity, price=price
        )

    def positions(self):
        return self.client.futures_position_information()
