from flask import Flask, render_template, request, jsonify
from trader import BasicBot
from history import get_trades, save_trade
import json

app = Flask(__name__)
bot = BasicBot()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/balance")
def get_balance():
    try:
        balance = bot.get_balance()
        return jsonify({"success": True, "data": balance})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/positions")
def get_positions():
    try:
        positions = bot.positions()
        active_positions = [p for p in positions if float(p.get("positionAmt", 0)) != 0]
        return jsonify({"success": True, "data": active_positions})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/price/<symbol>")
def get_price(symbol):
    try:
        ticker = bot.client.futures_symbol_ticker(symbol=symbol.upper())
        mark_price = bot.client.futures_mark_price(symbol=symbol.upper())
        return jsonify({
            "success": True,
            "data": {
                "price": float(ticker["price"]),
                "markPrice": float(mark_price["markPrice"])
            }
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/history")
def get_history():
    try:
        trades = get_trades()
        return jsonify({"success": True, "data": trades})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/market", methods=["POST"])
def market():
    try:
        data = request.get_json()
        symbol = data["symbol"].upper()
        side = data["side"].upper()
        qty = float(data["qty"])
        leverage = int(data.get("leverage", 1))
        
        if leverage > 1:
            bot.set_leverage(symbol, leverage)
        
        result = bot.market_order(symbol, side, qty)
        
        # Save trade to history
        save_trade({
            "symbol": symbol,
            "side": side,
            "qty": qty,
            "price": float(result.get("avgPrice", result.get("price", 0))),
            "orderId": result.get("orderId"),
            "type": "MARKET",
            "leverage": leverage
        })
        
        return jsonify({"success": True, "data": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/limit", methods=["POST"])
def limit():
    try:
        data = request.get_json()
        symbol = data["symbol"].upper()
        side = data["side"].upper()
        qty = float(data["qty"])
        price = float(data["price"])
        leverage = int(data.get("leverage", 1))
        
        if leverage > 1:
            bot.set_leverage(symbol, leverage)
        
        result = bot.limit_order(symbol, side, qty, price)
        
        # Save trade to history
        save_trade({
            "symbol": symbol,
            "side": side,
            "qty": qty,
            "price": price,
            "orderId": result.get("orderId"),
            "type": "LIMIT",
            "leverage": leverage
        })
        
        return jsonify({"success": True, "data": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
