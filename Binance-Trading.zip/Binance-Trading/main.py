from trader import BasicBot

bot = BasicBot()

while True:
    print("1. Market Order")
    print("2. Limit Order")
    print("3. Exit")
    choice = input("Choose: ")

    if choice == "1":
        print("Market order logic coming next")
    elif choice == "2":
        print("Limit order logic coming next")
    else:
        break


from trader import BasicBot

bot = BasicBot()

while True:
    print("\n=== BINANCE FUTURES TESTNET BOT ===")
    print("1. Market Order")
    print("2. Limit Order")
    print("3. Exit")

    ch = input("Choose: ")

    if ch == "1":
        s = input("Symbol (BTCUSDT): ").upper()
        side = input("Side (BUY/SELL): ").upper()
        qty = float(input("Quantity: "))
        lev = int(input("Leverage: "))
        bot.set_leverage(s, lev)
        res = bot.market_order(s, side, qty)
        print(res)

    elif ch == "2":
        s = input("Symbol: ").upper()
        side = input("Side: ").upper()
        qty = float(input("Quantity: "))
        price = float(input("Limit Price: "))
        res = bot.limit_order(s, side, qty, price)
        print(res)

    else:
        break

from utils import validate_side, validate_qty, validate_price

# inside while loop
try:
    if ch == "1":
        ...
        if not validate_side(side) or not validate_qty(qty):
            print("Invalid input")
            continue
except Exception as e:
    print("Error:", e)

print("3. Stop-Limit Order")
print("4. View Balance")
print("5. Exit")
elif ch == "3":
    s = input("Symbol: ").upper()
    side = input("Side: ").upper()
    qty = float(input("Quantity: "))
    stop = float(input("Stop Price: "))
    limit = float(input("Limit Price: "))
    print(bot.stop_limit(s, side, qty, stop, limit))

elif ch == "4":
    for b in bot.get_balance():
        if b["asset"] == "USDT":
            print("USDT Balance:", b["balance"])

from history import save_trade

save_trade({
    "symbol": s,
    "side": side,
    "qty": qty,
    "price": float(res["avgPrice"]) if "avgPrice" in res else float(res["price"]),
    "orderId": res["orderId"]
})
from history import get_trades

elif ch == "6":
    trades = get_trades()
    total = 0
    wins = 0

    for t in trades:
        pnl = calc_pnl(t["price"], t["price"], t["qty"], t["side"])
        total += pnl
        if pnl > 0:
            wins += 1

    print("Total Trades:", len(trades))
    print("Winning Trades:", wins)
    print("Net PnL:", round(total,2))

elif ch == "7":
    s = input("Symbol: ").upper()
    qty = float(input("Qty per grid: "))
    low = float(input("Lower price: "))
    high = float(input("Upper price: "))
    grids = int(input("Number of grids: "))
    bot.grid_trade(s, qty, low, high, grids)
